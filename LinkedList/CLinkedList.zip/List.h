#ifndef _LIST_H_
#define _LIST_H_
#include <stdlib.h>
#include <stdio.h>
#include "Node.h"
typedef struct List
{
      Node* head;
} List;
void cleanUp(List *list);
void add(List *list, int val);
void addToHead(List *list, int val);
void printList(List *list);
List *flip();
#endif
