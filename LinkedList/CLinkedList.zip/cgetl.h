#ifndef _CGETL_H_
#define _CGETL_H_
char* cgetl();
#endif
