#include "List.h"
#include "cgetl.h"

int main(void)
{
    srand(0);
    List* list = (List*) malloc(sizeof(List));
    list->head = 0;
    int i;
    
    for(i = 0; i < 2000; i++)
    {
          int r = (rand() % 350000) + 1;
          add(list, r);
    }
    
    printList(list);  
    cleanUp(list);
    cgetl();
    return 0;
}
