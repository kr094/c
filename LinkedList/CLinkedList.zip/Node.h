#ifndef _NODE_H_
#define _NODE_H_
typedef struct Node
{
 int val;
 struct Node* next;
} Node;
#endif
